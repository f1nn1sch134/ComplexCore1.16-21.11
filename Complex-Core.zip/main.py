print("Hello World")

VERSION = "1.2.0"